
import pymysql
conn = pymysql.connect(host='localhost',port=3306,user='guest',passwd='guest', db='mydata')

cur = conn.cursor()
sql = '''SELECT * FROM MYDATA.DATASET1'''
cur.execute(sql)
result = cur.fetchone()
print(result)
