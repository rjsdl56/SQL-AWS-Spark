
# 283 페이지.CODE
# MySQL과 R을 연동해 주는 패키지 설치
install.packages('RMySQL')
# 패키지 실행
library(RMySQL)
# 접속 정보 입력
mydb = dbConnect(MySQL(),
                 user='id',
                 password='password',
                 dbname='turnover',
                 host='server host')
# Database 내 존재하는 테이블 출력
dbListTables(mydb)
# 데이터 조회
dbGetQuery(mydb,'select * from turnover.data')


# 284 페이지.CODE
# MySQL과 R을 연동해 주는 패키지 설치
install.packages('RMySQL')
# 패키지 실행
library(RMySQL)
# 접속 정보 입력
mydb = dbConnect(MySQL(),
                 user='id',
                 password='password',
                 dbname='turnover',
                 host='server host')
# Database 내 존재하는 테이블 출력
dbListTables(mydb)
# 데이터 data
data = dbGetQuery(mydb,'select * from turnover.data')


# 285 페이지.CODE
options(scipen = 999)
model = lm(satisfaction_level~average_montly_hours,data=data)
model

# 286 페이지.CODE
summary(model)